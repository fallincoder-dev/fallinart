import Image from "next/image";
import Link from "next/link";

export default function ProjectPage() {
  return (
    <div className="px-6 md:px-16 lg:px-24 py-8">
      <h1 className="work-title mb-8">Street Photography</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16">
        <div className="space-y-6">
          <p className="text-lg md:text-xl">
            A collection of street style photography capturing fashion in its natural, urban environment.
          </p>
          <p className="text-lg">
            This ongoing project documents how fashion lives and breathes in the real world, away from studios and controlled environments.
          </p>
        </div>

        <div className="relative h-[400px] md:h-[600px]">
          <Image
            src="https://ext.same-assets.com/4233618056/787278551.jpeg"
            alt="Street Photography"
            fill
            style={{objectFit: "cover"}}
            priority
          />
        </div>
      </div>

      <div className="mt-16">
        <Link href="/selectworks" className="text-primary hover:underline">
          ← Back to Select Works
        </Link>
      </div>
    </div>
  );
}
